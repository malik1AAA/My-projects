<?php
include("connection.php");
error_reporting(0);
$pic=$_GET['pic'];
$query= "select * from record WHERE Reg_No='$reg_no'";
$data=mysqli_query($conn,$query);
if($data)
{
  echo "<script>alert(Record search from database)</script>";
}
else
{
  echo "<font color='red'>Failed to search record deleted from database";
}

?>

  <META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://localhost/Student Information.com/new_arrivals2.php">;

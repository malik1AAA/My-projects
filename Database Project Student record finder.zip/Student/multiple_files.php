<!-- <html>
<body>

</body>
</html> -->


 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <title>Student Information.com</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="theme-color" content="#03a6f3">
     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800,900" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/styles.css">
 </head>

 <body>
   <header>
       <div class="header-top">
           <div class="container">
               <div class="row">
                   <div class="col-md-3"><a href="#" class="web-url"></a></div>
                    <div class="col-md-6">
                        <h5>UET Lahore, Narowal Campus</h5></div>
                    <div class="col-md-3">
                        <span class="ph-number">Call: +9243545436</span>
                   </div>
               </div>
           </div>
       </div>
       <div class="main-menu">
           <div class="container">
               <nav class="navbar navbar-expand-lg navbar-light">
                   <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a>
                   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                       <span class="navbar-toggler-icon"></span>
                   </button>
                   <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       <ul class="navbar-nav ml-auto">
                           <li class="navbar-item ">
                               <a href="session.php" class="nav-link">Home</a>
                            </li>
                             <li class="navbar-item">
                                <a href="bme.php" class="nav-link">BME</a>
                            </li>
                             <li class="navbar-item">
                                <a href="cse.php" class="nav-link">CSE</a>
                            </li>
                             <li class="navbar-item">
                                <a href="civil.php" class="nav-link">CE</a>
                            </li>
                             <li class="navbar-item">
                                <a href="mechaniacl.php" class="nav-link">ME</a>
                            </li>
                             <li class="navbar-item">
                                <a href="electrical.php" class="nav-link">EE</a>
                            </li>
                            <li class="navbar-item active">
                                <a href="about1.php" class="nav-link">About</a>
                            </li>
                            <li class="navbar-item">
                                <a href="faq1.php" class="nav-link">FAQ</a>
                            </li>
                            <li class="navbar-item">
                                <a href="profile.php" class="nav-link">Profile</a>
                           </li>
                       </ul>
                       <!-- <div class="cart my-2 my-lg-0">
                           <span>
                               <i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
                           <span class="quntity">3</span>
                       </div>
                       <form class="form-inline my-2 my-lg-0">
                           <input class="form-control mr-sm-2" type="search" placeholder="Search here..." aria-label="Search">
                           <span class="fa fa-search"></span> -->
                       </form>
                   </div>
               </nav>
           </div>
       </div>
   </header>
     <!-- <div class="breadcrumb">
         <div class="container">
           <a class="breadcrumb-item" href="index.html">Home</a>
           <span class="breadcrumb-item active"><a href="display.php">Records</a></span>
           <span class="breadcrumb-item active"><a href="update.php">Update</a></span>
           <span class="breadcrumb-item active"><a href="multiple_files.php">Add Items</a></span>
         </div>
     </div> -->
     <section class="static about-sec">
         <div class="container">
           <div class="breadcrumb">
               <div class="container">
             <h1>Admin /Add recordes/ View Recordes</h1>
           </div>
       </div>
           <p> Student Information. com is system of UET Narowal in which we store all data od students like name, rool_no, reg_no, cnic, internship, comments, job place etc.</p>
            <div class="form">
             <form action="#"  method="post" enctype="multipart/form-data">
                 <!-- <form> -->
                     <div class="row">
                     <input type="file" name="doc[]" multiple><br><br><br>
                     <button class="btn black"  Name="submit" value="" Mobile="submit" value"" CNIC="submit" value"" Reg_No="submit" value"" Personal_Email="submit" value""University_Email="submit" value""Session="sumit" value"" Deapartment="submit" value"" Internship="submit" value"" UNI_Recmend_letter_img="submit" uploadfile "" Company_feedback_comment="submit" value "" Company_feedback_img="submit" uploadfile "" job_place="submit" value "" status="submit" value "" previous="submit" value=>Uploadfile(s)""</button>
                     <?php
                     include("connection.php");
                     //error_reporting(0);
                     if(isset($_POST['submit']))
                     {
                       //echo '<pre>';
                       //  print_r($_FILES);
                       foreach($_FILES['doc']['name'] as $key=>$val)
                       {
                         // $random=rand('11111','99999');
                         $file="record/".$val;
                         move_uploaded_file($_FILES['doc']['tmp_name'][$key],'record/'.$val);
                         $query="INSERT into record VALUES ('$file')";
                         $data=mysqli_query($conn,$query);
                         if($data)
                         {
                           echo "File(s) Uploaded into DAtabase";
                         }
                         else {
                           {
                             "Failed";
                           }
                         }
                       }
                     }
                     ?>
                     <!-- </form> -->
                     </div>
                 </form>
             </div>
             <div class="form">
                     <form>
                       <h1> Orders </h1>
                         <div class="row">

                             <table border="2" cellspacing="7">
                               <style type="text/css">
                               table tr#ROW1,th {
                                 background-color:#fcba68 ;
                                  color:black ;
                                  text-align: center;
                                  padding: 15px 25px;

                                }
                                table td {
                                  text-align: center;
                                  padding: 15px 25px;
                                }

                                 a:link, a:visited {
                                 background-color: white;
                                 color: black;
                                 padding: 15px 25px;
                                 text-align: center;
                                 text-decoration: none;
                                 display: inline-block;
                               }
                                a:hover, a:active {
                                 background-color: #fcba68;
                               }
                             </style>

                               <tr id="ROW1">
                                 <th >Name</th>
                                 <th >CNIC</th>
                                 <th>Reg_No</th>
                                 <th> Delete</th>
                               </tr>
                           <?php
                           include("connection.php");
                           error_reporting(0);
                           $query="SELECT * from record WHERE Name, Reg_No, CNIC ";
                           $data=mysqli_query($conn,$query);
                           $total=mysqli_num_rows($data);
                           //1echo $total;
                           if ($total!=0)
                           {
                           while(($result=mysqli_fetch_assoc($data)))
                             {
                               echo "
                               <tr>
                              <td>"$result['Name']"</td>
                               <td>"$result['Name']"</td>
                               <td>"$result['Reg_No']"</td>
                                <td>"$result['CNIC']"</td>

                               <td><a href='delete_recored.php?num=$result[Name, Reg_No, CNIC]' onclick= 'return checkdelete()' >Delete</td>
                               </tr>
                               ";
                             }
                           }
                           else
                           {
                             echo "<br><br><br><br><br>no records found";
                           }
                            ?>
                           </table>

                           <script>
                           function checkdelete()
                           {
                             return confirm('Are  you sure you want to delete record');
                           }
                           </script>


                         </div>
                     </form>
                 </div>
         </div>
     </section>
     <footer>
         <div class="copy-right">
             <div class="container">
                 <div class="row">
                     <div class="col-md-6">
                         <h5>(C) 2021. All Rights Reserved. Student Information.com </h5>
                     </div>
                     <div class="col-md-6">
                         <div class="share align-middle">
                             <span class="fb"><i class="fa fa-facebook-official"></i></span>
                             <span class="instagram"><i class="fa fa-instagram"></i></span>
                             <span class="twitter"><i class="fa fa-twitter"></i></span>
                             <span class="pinterest"><i class="fa fa-pinterest"></i></span>
                             <span class="google"><i class="fa fa-google-plus"></i></span>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </footer>
     <script src="js/jquery.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script type="text/javascript" src="js/owl.carousel.min.js"></script>
     <script src="js/custom.js"></script>
 </body>
 </html>

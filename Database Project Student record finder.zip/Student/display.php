<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Student Information.com</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#03a6f3">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
  <header>
      <div class="header-top">
          <div class="container">
              <div class="row">
                  <div class="col-md-3" class="web-url"></div>
                  <div class="col-md-6">
                        <h5>UET Lahore, Narowal Campus</h5></div>
                    <div class="col-md-3">
                        <span class="ph-number">Call: +9243545436</span>
                  </div>
              </div>
          </div>
      </div>
      <div class="main-menu">
          <div class="container">
              <nav class="navbar navbar-expand-lg navbar-light">
                  <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav ml-auto">
                          <li class="navbar-item ">
                              <a href="session.php" class="nav-link">Home</a>
                            </li>
                             <li class="navbar-item">
                                <a href="bme.php" class="nav-link">BME</a>
                            </li>
                             <li class="navbar-item">
                                <a href="cse.php" class="nav-link">CSE</a>
                            </li>
                             <li class="navbar-item">
                                <a href="civil.php" class="nav-link">CE</a>
                            </li>
                             <li class="navbar-item">
                                <a href="mechaniacl.php" class="nav-link">ME</a>
                            </li>
                             <li class="navbar-item">
                                <a href="electrical.php" class="nav-link">EE</a>
                            </li>
                            <li class="navbar-item active">
                                <a href="about1.php" class="nav-link">About</a>
                            </li>
                            <li class="navbar-item">
                                <a href="faq1.php" class="nav-link">FAQ</a>
                            </li>
                            <li class="navbar-item">
                                <a href="profile.php" class="nav-link">Profile</a>
                          </li>
                      </ul>
                      <!-- <div class="cart my-2 my-lg-0">
                          <span>
                              <i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
                          <span class="quntity">3</span>
                      </div>
                      <form class="form-inline my-2 my-lg-0">
                          <input class="form-control mr-sm-2" type="search" placeholder="Search here..." aria-label="Search">
                          <span class="fa fa-search"></span> -->
                      </form>
                  </div>
              </nav>
          </div>
      </div>
  </header>
    <section class="static about-sec">
        <div class="container">
          <div class="breadcrumb">
              <div class="container">
                <h1>  Display SignUp records by Student Information.com </h1>

              </div>
          </div>
        <div class="form">
                <form>
                    <div class="row">
                        <table border="2" cellspacing="7">
                          <style type="text/css">
                          table tr#ROW1,th {
                            background-color:#fcba68 ;
                             color:black ;
                             text-align: center;
                             padding: 15px 25px;

                           }
                           table td {
                             text-align: center;
                             padding: 15px 25px;
                           }

                            a:link, a:visited {
                            background-color: white;
                            color: black;
                            padding: 15px 25px;
                            text-align: center;
                            text-decoration: none;
                            display: inline-block;
                          }
                           a:hover, a:active {
                            background-color: #fcba68;
                          }
                        </style>
                          <tr id="ROW1">
                            <th >Username</th>
                            <th>Operations</th>
                             <th>Operations</th>
                          </tr>
                      <?php
                      include("connection.php");
                      error_reporting(0);
                      $query="SELECT * from user_register WHERE password>1 ";
                      $data=mysqli_query($conn,$query);
                      $total=mysqli_num_rows($data);
                      //1echo $total;
                      if ($total!=0)
                      {
                        while(($result=mysqli_fetch_assoc($data)))
                        {
                          echo "
                          <tr>
                          <td>".$result['username']."</td>
                          <td>".$result['email']."</td>

                          <td><a href='update.php?un=$result[username]&em=$result[email]'  >Edit/Update
                          <a href='delete.php?em=$result[email]' onclick= 'return checkdelete()' >Delete
                          <a href='delete_by_name.php?em=$result[email]' onclick= 'return checkdelete()' >Delete by Name
                          <a href='delete_by_cnic.php?em=$result[email]' onclick= 'return checkdelete()' >Delete by CNIC
                          <a href='delete_by_reg_no.php?em=$result[email]' onclick= 'return checkdelete()' >Delete by Reg. No
                          </td>
                          <td>
                          <a href='insert.php?em=$result[email]' onclick= 'return checksearch()' >Insert
                          <a href='search_by_name.php?em=$result[email]' onclick= 'return checksearch()' >Search by Name
                          <a href='search_by_cnic.php?em=$result[email]' onclick= 'return checksearch()' >Search by CNIC
                          <a href='search_by_reg_no.php?em=$result[email]' onclick= 'return checksearch()' >Search by Reg. No
                          </td>
                          </tr>
                          ";
                        }
                      }
                      else
                      {
                        echo "no records found";
                      }
                       ?>
                      </table>
                      <script>
                      function checkdelete()
                      {
                        return confirm('Are  you sure you want to delete record');
                      }
                      </script>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <footer>
        <div class="copy-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h5>(C) 2021. All Rights Reserved. Student Information.com </h5>
                    </div>
                    <div class="col-md-6">
                        <div class="share align-middle">
                            <span class="fb"><i class="fa fa-facebook-official"></i></span>
                            <span class="instagram"><i class="fa fa-instagram"></i></span>
                            <span class="twitter"><i class="fa fa-twitter"></i></span>
                            <span class="pinterest"><i class="fa fa-pinterest"></i></span>
                            <span class="google"><i class="fa fa-google-plus"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>

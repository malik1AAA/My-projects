<?php
session_start();
session_unset();
session_destroy();
echo "<script type='text/javascript'>alert('Succesfully Logout');</script>";
echo "<script type='text/javascript'>window.top.location='admin.php';</script>";
?>

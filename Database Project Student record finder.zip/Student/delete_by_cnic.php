<?php
include("connection.php");
error_reporting(0);
$pic=$_GET['pic'];
$query= "DELETE * FROM record WHERE CNIC='$cnic'";
$data=mysqli_query($conn,$query);
if($data)
{
  echo "<script>alert(Record deleted from database)</script>";
}
else
{
  echo "<font color='red'>Failed to delete record deleted from database";
}

?>

  <META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://localhost/Student Information.com/new_arrivals2.php">;



  <?php
include_once 'connection.php';
$result = mysqli_query($conn,"SELECT * FROM record");
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<title>Delete student data</title>
</head>
<body>
<table>
	<tr>
	<td>Name</td>
	<td>Gender</td>
	<td>CNIC</td>
	<td>Deapartment</td>
	<td> Session</td>
	<td>Reg_No</td>
	
	</tr>
	<?php
	$i=0;
	while($row = mysqli_fetch_array($result)) {
	?>
	<tr class="<?php if(isset($classname)) echo $classname;?>">
	<td><?php echo $row["userid"]; ?></td>
	<td><?php echo $row["first_name"]; ?></td>
	<td><?php echo $row["last_name"]; ?></td>
	<td><?php echo $row["city_name"]; ?></td>
	<td><?php echo $row["email"]; ?></td>
	<td><a href="delete-process.php?userid=<?php echo $row["userid"]; ?>">Delete</a></td>
	</tr>
	<?php
	$i++;
	}
	?>
</table>
</body>
</html>

<?php
$servername="localhost";
$username="root";
$password="";
$dbname="student_record";

$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{
  //echo"Connection OK";
}
else
{
  echo "connection failed".mysqli_connect_error();
}
?>

